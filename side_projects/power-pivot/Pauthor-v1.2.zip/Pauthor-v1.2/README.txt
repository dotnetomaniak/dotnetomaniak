This package contains the binary-only release of the Pivot Collection
Tool for the Command Line (a.k.a. Pauthor).  It contains both the
Pauthor executable as well as the PauthorLib DLL containing the same
functionality. The executable may be incorporated into any DOS-based
workflow for creating static collections, and the PauthorLib library
may be used in any program to produce Pivot collection content.

For full details, go to: http://pauthor.codeplex.com/documentation

